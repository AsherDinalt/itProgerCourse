#include <iostream>

void add(int x, int y) {
	std::cout << (x + y) << std::endl;
}

void add(int x, int y, int z) {
	std::cout << (x + y + z) << std::endl;
}

void mult(int x, int y) {
	std::cout << (x * y) << std::endl;
}

void minus(int x, int y) {
	std::cout << (x - y) << std::endl;
}