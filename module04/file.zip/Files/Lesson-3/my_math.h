#pragma once

void add(int x, int y);
void add(int x, int y, int z);
void mult(int x, int y);
void minus(int x, int y);

